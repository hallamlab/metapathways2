// Public domain code from Yi-Kuo Yu & Stephen Altschul, NCBI

#ifndef __LUDCMP_
#define __LUDCMP_

void ludcmp(double **a,int n, int *indx,double *d);

#endif
