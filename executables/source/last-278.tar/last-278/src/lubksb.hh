// Public domain code from Yi-Kuo Yu & Stephen Altschul, NCBI

#ifndef __LUBKSB_
#define __LUBKSB_

void lubksb(double **a,int n,int *indx,double b[]);

#endif
