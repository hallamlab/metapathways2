#ifndef CORELIB___NCBITYPE__H
#define CORELIB___NCBITYPE__H

typedef signed   int   Int4;    /**< Alias for signed int */
typedef unsigned int   Uint4;   /**< Alias for unsigned int */

#endif  /* CORELIB___NCBITYPE__H */
