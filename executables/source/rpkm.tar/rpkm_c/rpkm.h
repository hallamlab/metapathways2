#ifndef _RPKM_HEADER
#define _RPKM_HEADER

#include <algorithm>
#include <vector>

#endif //_RPKM_HEADER
