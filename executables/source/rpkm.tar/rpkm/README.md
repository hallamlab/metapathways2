rpkm_c
======

C++ implementation of reads per kilobase mapped statistic.
